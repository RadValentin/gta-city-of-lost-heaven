_______________________________________________________________________
 __  ___             __  __     ___        __  ___               __  _ 
|     |   /\   |\/| |  | | \     |  |\  | |     |   /\  |   |   |   | \
| _   |  |--|  |  | |  | |  |    |  | \ | |__   |  |--| |   |   |-  |-/
|__|  |  |  |  |  | |__| |__|   _|_ |  \| ___|  |  |  | |__ |__ |__ | \
------------------------------------------------------------------------

 ----------------------------------------
| Program Name:      GTA Mod Installer   |
 ----------------------------------------
| Program Version:   v5.0 beta           |
 ----------------------------------------
| Creator:           cpmusick            |
 ----------------------------------------
| Email Address:  cpmusick@gtavicehq.com |
 ----------------------------------------
| Website URL:  http://www.gtavicehq.com |
 ----------------------------------------


 ----------------------------------------
|            Beta Information            |
 ----------------------------------------

NOTE: This is a beta version of GMI (GTA Mod Installer). It does not 
contain all of the features that will be in the final version of 5.0. 
Also note that this beta does not support backups for GXT files. If you 
restore a backup (uninstall a mod), the GXT file will not be changed back.

If you come across any errors, then please email me at cpmusick@gtavicehq.com. 
Please explain what you did, when you got the error, and the error message (if 
there was one). I'll be sure to fix the error for the final version 5.0.


 ----------------------------------------
|   What the Purpose of This Program?    |
 ----------------------------------------

This program was created so that it would be a whole lot easier to
install custom vehicles and mods into both GTA3 and GTA Vice City.


 ----------------------------------------
|         What Are the Features?         |
 ----------------------------------------

---Install Mods Using Script Files--

-If a mod comes with a script file(s), then the mod will be installed
 automatically, according to the instructions in the script file.

-Can have multiple script files, meaning if the mod can be installed
 to GTA3 and Vice City, there's a separate script for each game.

-Can have uninstall scripts as well, which are used for automatically
 uninstalling the mod\vehicle. Though uninstall scripts are rare and
 generally not needed, now that there's backup support.

-Ability to backup all files that are modified by a mod\vehicle (optional). You 
 can also reinstall those files by using the mod installer and selecting 
 the backup dir. This is possible because the mod installer generates a script 
 for the backed up files.

-Quick and easy backup restoring. It shows a listing of backups found and lets
 you choose one to restore.


-----Install Vehicles-----

-Ability to automatically search for and install the DFF and TXD files
 for the custom vehicle.

-Automatically search for and insert any handling.cfg, carcols.dat, and
 default.ide info in the readme for that car.

-Allows the user to choose which car they want to replace. All files and 
 necessary handling lines will be renamed and adjusted accordingly.

-Can automatically convert GTA3 cars to Vice City and Vice City cars 
 to GTA3, including all DFF\TXD files as well as the necessary handling lines.
 This is all automatic, so no input is required from the user.

-Allow the installation of both GTA3 and GTA Vice City custom vehicles
 in one simple and easy to use program.

-Edits all necessary files automatically, including the handling.cfg,
 carcols.dat, default.ide, and IMG files.

-Support for editing GXT files, which means you can change the name of the
 car as it appears in the game.

-Automatically uses the original handling.cfg, default.ide, and carcols.dat
 info if either of those lines were not provided with the custom vehicle.

-ZIP and RAR file support. Just select the ZIP or RAR file you downloaded for 
 the car and it gets extracted and installed automatically.

-Automatic DMagic1 Wheel Mod detection and installation. If the mod is not
 installed, then the GMI can automatically install (or repair) it. No download 
 required.

-------------------------------------------------------------------------

Version 5.0 beta
-GXT Support. You can now edit GXT files for custom car names, or any other text for other mods. NOTE: This beta does not backup edited GXT files.
-New and much easier backup restoring. It displays a list of all backups in your GTA folder and lets you choose one to restore.
-Improved automatic update. Now it automatically checks for updates every five days.
-Built-in DMagic1 Wheel Mod installation. If the user doesn't have it installed, GMI will install it automatically (no download required).
-Ability to restart GMI automatically after installing a mod (for installing multiple mods).
-GTA Mod Installer's version is now stored in scripts for mods. This ensures that the mod can't be installed with an older, incompatible version of GMI (starts with v5.0).
-Detects if backup folder already exists. If so, the user is asked if they want to overwrite the existing backup.
-Optional ability to automatically remove a backup folder (and files) for a mod after restoring the backup.
-Other miscellaneous improvements and bug fixes.

Version 4.1 Changes
-Automatic DMagic1 Wheel Mod detection. If the mod is not installed and a vehicle
 requires the mod, it then tells the user where to download it.
-Fixed the problem with the game freezing during loading when installing some vehicles,
 which means better handling.cfg, default.ide, and carcols.dat line inserting.
-Files no longer have to be in the same directory as the script to be installed.
-Physics line validator.
-Ignores "comment" lines in text\config files, which begin with "#" or ";"
-Fixed RAR support for mods with script files.
-Better backup script generating.
-Other various improvements, bug fixes, and changes.
-Features in Scripter v2.0:
	-Much better design and more user-friendly.
	-Ability to use a  "virtual directory", which will put all the mod's files
	 (and script) there, so that they can be zipped easily all from one place.
	-Better error detecting.
	-Other miscellaneous improvements.

Version 4.0 Changes
-Ability to choose which car to replace.
-Ability to automatically detect and convert GTA3 cars to Vice City and Vice City cars to GTA3.
-Added support for RAR files.
-Added automatic update feature.
-New and better method for default.ide, handling.cfg, and carcols.dat line detecting, which is about 99% accurate.
-Fixed bug with "Invalid Game Path" when it's actually valid.
-Fixed problem with cars replacing the Greenwood and Line Runner.
-Fixed problem with cars not changing for some people (making the necessary files to not be read-only).
-Fixed bug with it not remembering the Vice City game directory.
-One-step installing when restoring a vehicle that was previously backed up.
-Other miscellaneous bug fixes and improvements.

Version 3.0 Changes
-Ability to backup all files that are modified by a mod (optional). You can also reinstall those files 
by using the mod installer and selecting the backup dir. This is possible because the mod 
installer generates a script for the backed up files.
-Better directory validation
-Ability to display the mod's name (if specified in script)
-Ability to display a text file after installing any mod (if the creator specifies one in the script)
-Improved\Fixed a few other things as well
-Features in scripter v1.1:
	-Fixed problem with the 100 character limit.
	-Added ablility to specify a name for the mod.
	-Added ability to specify a text file to be shown after user installs the mod.

Version 2.2 Changes
-Fixed bugs installing Vice City cars, as well as inserting original
 handling lines for both GTA and Vice City.

Version 2.1 Changes
-Fixed some bugs when using multiple script files.

Version 2.0 Changes
-Added script support, which allows mods to be installed or uninstalled by following
 the directions in the script file(s).
-It now sets all necessary files to NOT be Read-Only. This helps prevent problems
 when installing vehicles\mods.
-Added support for inserting cutom-made colors to be added to the carcols.dat color 
 list (if the vehicle comes with that info).
-Improved error detection for the handling.cfg, default.ide, and carcols.dat lines.

Version 1.2 Changes
-Big bug fixes for some of the Vice City vehicle installations (due to some cars having
 a different name in the default.ide than the handling.cfg).
-Zip file support. Automatically extracts the selected ZIP and installs the vehicle.
-Automatically inserts original default.ide, handling.cfg, and carcols.dat lines if
 either of them aren't provided with the custom vehicle. This helps prevent major errors.
-Better vehicle database management and detection.
-Install stops if the txd.img file is not found (for GTA3 cars). This keeps the car's
 TXD file from being installed wrong.
-When finished, it tells which car was replaced.
-Improved error detection even more.

Version 1.1 Changes
 -DFF and TXD files are detected automatically and more accurately.
 -No longer have to choose which car it replaces. It now detects that 
  automatically.
 -Much Better error detection. If an error is found, it tells you why and 
  how to fix it.
 -Better handling.cfg, default.ide, and carcols.dat detection.



 ----------------------------------------
|            How Do I Use IT?            |
 ----------------------------------------
It's pretty self-explainatory. Just read the information on each
screen, and it will be very simple to use. Some mods may
come with script files (installscript***.txt). If so, then 
you can choose the "Install a Mod" option to automatically install that 
mod, which will use the instructions provided in the script.



 ----------------------------------------
|    What Will Be In Future Versions?    |
 ----------------------------------------

-Possible audio editing support. This means that you would be able to 
extract\replace\add new audio to the game by editing the sfx file. 
-If there's any bugs, those will be fixed.
-Whatever else I think of later.


 ----------------------------------------
|      Contact Info and Bug Reports      |
 ----------------------------------------
If you would like to contact me (cpmusick) for any reason, send me an
email at cpmusick@gtavicehq.com and I'll respond as soon as I can.

If you have any suggestions, find any bugs, or have any problems with
GTA Mod Installer, then please email me explaining the situation. If 
you receive an error message while using GMI, then please include it 
in the email.


 ----------------------------------------
|            Legal Information           |
 ----------------------------------------
This program is to not be used\modified\distributed in an illegal form. 
This includes modifying it, releasing it under another name or anything 
else that involves theft or copyright abuse.

I don't mind if you host it on any website, just as long as you give me 
(cpmusick) the proper credit for making this program.





Thanks, and enjoy GTA Mod Installer!