===================
 VC Limit Adjuster
===================
 Version 1.0
 25. 07. 2003
===================

E-Mail: st.mu@web.de
Web: http://people.freenet.de/steve-m


IMPORTANT!
~~~~~~~~~~

This program is freeware and can freely be spread, as long as this readme is included and no changes to both the program and the readme were made!
I take no responsibility of any damage caused by the usage of this product!


Installation and deinstallation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

No installation necessary.
Just extract the file into one directory und delete it after use.


Brief instructions
~~~~~~~~~~~~~~~~~~

This tool can be used to change the hardcoded limitations for objects und other stuff. Click on the info button next to the edit box to learn more about a value.
Please let me know, if you found out, what one of the unknown values is used for.


History
~~~~~~~

Version 1.0 (25. 07. 2003)
- first public release
- added streaming memory value
- added infos
- added statistics

Version 0.1 (05. 07. 2003)
- non-public beta


If there are any problems, questions, mistakes, bugs or something else simply send an email! (st.mu@web.de)

Greetings

Steve